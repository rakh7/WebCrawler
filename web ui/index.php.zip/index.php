<?php
	header("Content-Type:text/html;charset=utf-8");
	$limit = 50;
	$query = isset($_GET['q'])? $_GET['q']:false;
	$port = isset($_GET['pagerank'])? 8984:8983;
	$core = isset($_GET['pagerank'])? "solr/SCrawler/":"solr/RCrawler/";
	$currentDoc = null;
	$previousDoc = null;
	// if(!fileTracker){
	// 	fileTracker = new array(50);
		
	// }
	echo $core;
	$results = false;
	if($query){
		try{

			require_once('Apache/Solr/Service.php');
			$solr = new Apache_Solr_Service('localhost',8983, $core);
			if(get_magic_quotes_gpc() == 1){
				$query = stripcslashes($query);
			}
		
			$results = $solr->search($query, 0, $limit);
		}catch(Exception $e){
			die("<html><head><title>SEARCH EXCEPTION</title></head><body><pre>{$e}</pre></body></html>");
		}
	}
	
?>
<!DOCTYPE html>
<html>
<head>
	<title>RCrawler</title>
</head>
<body>
<form accept-charset="utf-8" method="get" action="index.php">
	<label for="q">Search:</label>
	<input id="q" name="q" type="text" value="">
	<br/><br/>
	<label for="pagerank">Use page rank algorithm </label>
	<input type="checkbox" id="pagerank" name="pagerank"></input><br/><br/>
	<input type="submit"></input>
	<br/><br/>
</form>
<?php
if($results){
	$total = (int)$results->response->numFound;
	$start = min(1, $total);
	$end = min($limit, $total);

?>
<div>
	Results<?php echo $start;?> - <?php echo $end;?> of <?php echo $total;?>:
</div>
<ol>
	<?php
		$count = 0;
		$checkContent = false;
		$urlMapper = array();
		if (($handle = fopen("urlTracker.csv", "r")) !== FALSE) {
			while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
			    $urlMapper[$data[1]] = $data[0];
			}
			fclose($handle);
		}
		//var_dump($urlMapper);

		// var_dump($results->response->docs);
		foreach($results->response->docs as $doc) {
			$previousDoc = $currentDoc;
			$filePath = "file:///".$doc->id;
			$currentDoc = file_get_contents($filePath);
			$files = explode("/", $doc->id);
			$fileSize = sizeof($files);
			$fileName = $urlMapper[$files[$fileSize-1]];
			echo $fileName;
			//echo $currentDoc."\n".$previousDoc."\n";
			if(md5(strip_tags($currentDoc)) == md5(strip_tags($previousDoc))){
				$checkContent = true;
			}else{
				$count++;
				$checkContent = false;
			}
			if($count==11)
				break;
			if($checkContent ==false){
			?>
				<li>
					<p><a href="<?php echo $fileName;?>" target="_blank">Document<?php echo $doc->id;?></a><?php echo " ".$doc->title?></p>
				</li>
			<?php 
	    	}
		}
	?>
</ol>
<?php
}?>
<script type="text/javascript">
	function loadURL(url){
		console.log(url);
		var win = window.open(url, '_blank');
  		win.focus();
	}
</script>
</body>
</html>